function openNav() {
    document.getElementById("mySidenav").style.width = "250px";	
}
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
}
function openSP() {
    document.getElementById("searchpat").style.width = "250px";
}
function closeSP() {
    document.getElementById("searchpat").style.width = "0";
}
function openUA() {
    document.getElementById("upcomapp").style.width = "250px";
}
function closeUA() {
    document.getElementById("upcomapp").style.width = "0";
}
function openPC() {
    document.getElementById("pastcon").style.width = "250px";        
}
function closePC() {
    document.getElementById("pastcon").style.width = "0";
}
function openIC() {
    document.getElementById("inccon").style.width = "250px";
}
function closeIC() {
    document.getElementById("inccon").style.width = "0";
}
function openANP() {
    document.getElementById("addnewpat").style.width = "250px";
}
function closeANP() {
    document.getElementById("addnewpat").style.width = "0";
}
function openBR() {
    document.getElementById("bulkreg").style.width = "250px";
}
function closeBR() {
    document.getElementById("bulkreg").style.width = "0";
}
function openBC() {
    document.getElementById("bulkcon").style.width = "250px";
}
function closeBC() {
    document.getElementById("bulkcon").style.width = "0";
}
function openC() {
    document.getElementById("consultation").style.width = "250px";
}
function closeC() {
    document.getElementById("consultation").style.width = "0";
}
function openMC() {
    document.getElementById("medCer").style.width = "250px";
}
function closeMC() {
    document.getElementById("medCer").style.width = "0";
}
function openFC() {
    document.getElementById("fitCer").style.width = "250px";
}
function closeFC() {
    document.getElementById("fitCer").style.width = "0";
}
function openT() {
    document.getElementById("tracker").style.width = "250px";
}
function closeT() {
    document.getElementById("tracker").style.width = "0";
}
function openRC() {
    document.getElementById("resumecon").style.width = "250px";
}
function closeRC() {
    document.getElementById("resumecon").style.width = "0";
}
function openBA() {
    document.getElementById("bookapp").style.width = "250px";
}
function closeBA() {
    document.getElementById("bookapp").style.width = "0";
}
function openCA() {
    document.getElementById("cancelapp").style.width = "250px";
	
}
function closeCA() {
    document.getElementById("cancelapp").style.width = "0";
}
function openFE() {
    document.getElementById("fullemr").style.width = "250px";
}
function closeFE() {
    document.getElementById("fullemr").style.width = "0";
}

//functions for consultation page of doctor
function openNavCon() {
    document.getElementById("mySidenavCon").style.width = "250px";	
}
function closeNavCon() {
    document.getElementById("mySidenavCon").style.width = "0";
}
function openRF() {
    document.getElementById("openRF").style.width = "250px";	
}
function closeRF() {
    document.getElementById("openRF").style.width = "0";
}
function openA() {
    document.getElementById("openA").style.width = "250px";	
}
function closeA() {
    document.getElementById("openA").style.width = "0";
}
function openTC() {
    document.getElementById("openTC").style.width = "250px";	
}
function closeTC() {
    document.getElementById("openTC").style.width = "0";
}
function openNC() {
    document.getElementById("openNC").style.width = "250px";	
}
function closeNC() {
    document.getElementById("openNC").style.width = "0";
}
function openPV() {
    document.getElementById("openPV").style.width = "250px";	
}
function closePV() {
    document.getElementById("openPV").style.width = "0";
}
function openPR() {
    document.getElementById("openPR").style.width = "250px";	
}
function closePR() {
    document.getElementById("openPR").style.width = "0";
}
function openSH() {
    document.getElementById("openSH").style.width = "250px";	
}
function closeSH() {
    document.getElementById("openSH").style.width = "0";
}
function openDE() {
    document.getElementById("openDE").style.width = "250px";	
}
function closeDE() {
    document.getElementById("openDE").style.width = "0";
}
function openDC() {
    document.getElementById("openDC").style.width = "250px";
	closeNavCon();	
}
function closeDC() {
    document.getElementById("openDC").style.width = "0";
	openNavCon();
}
function openERP() {
    document.getElementById("openERP").style.width = "250px";	
	closeNavCon();
}
function closeERP() {
    document.getElementById("openERP").style.width = "0";
	openNavCon();
}
function openSRP() {
    document.getElementById("openSRP").style.width = "250px";	
	closeNavCon();
}
function closeSRP() {
    document.getElementById("openSRP").style.width = "0";
	openNavCon();
}
function openST() {
    document.getElementById("openST").style.width = "250px";
	closeNavCon();	
}
function closeST() {
    document.getElementById("openST").style.width = "0";
	openNavCon();
}
function openTEM() {
    document.getElementById("openTEM").style.width = "250px";	
	closeNavCon();
}
function closeTEM() {
    document.getElementById("openTEM").style.width = "0";
	openNavCon();
}
function openPLP() {
    document.getElementById("openPLP").style.width = "250px";
	closeNavCon();	
}
function closePLP() {
    document.getElementById("openPLP").style.width = "0";	
	openNavCon();
}
function openI() {
    document.getElementById("openI").style.width = "250px";	
	closeNavCon();
}
function closeI() {
    document.getElementById("openI").style.width = "0";
	openNavCon();
}